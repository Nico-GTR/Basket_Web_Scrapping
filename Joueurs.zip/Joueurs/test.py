# -*- coding: utf-8 -*-
"""
Created on Sat Dec  7 15:07:34 2024

@author: Manoubi
"""

import os
import requests
import pandas as pd
from bs4 import BeautifulSoup
from io import StringIO

from lookup import lookup
from players import get_player_suffix,get_game_logs,get_player_splits,get_player_headshot

from selenium import webdriver
from selenium.webdriver.common.by import By
import pandas as pd

from Scrapping_joueur import get_player_splits_clean,get_player_logs_clean,get_game_highs,get_stats
def verification_dossier(base_path, nom_joueur):
    dossier = os.path.join(base_path, nom_joueur)
    return os.path.exists(dossier)

def creation_dossier(base_path, nom_joueur):
    dossier = os.path.join(base_path, nom_joueur)
    if not os.path.exists(dossier):
        os.makedirs(dossier)
    return dossier
    
def scrapping_joueur(nom_joueur,dossier_joueur):
    # Vérifier si le dossier éxiste 
    dossier_verifié = verification_dossier(dossier_joueur, nom_joueur)
    
    if dossier_verifié == False:
        # Création du dossier du joueur
        dossier = creation_dossier(dossier_joueur, nom_joueur)
        
        # Créer le DataFrame et le sauvegarder dans le fichier
        stats = get_stats(nom_joueur)
        stats.to_csv(f"{dossier}\stats.csv",index =False)
        
        game_highs = get_game_highs(nom_joueur)
        game_highs.to_csv(f"{dossier}\game_highs.csv", index = False)
        
        salary = get_salary(nom_joueur)
        salary.to_csv(f"{dossier}\salary.csv", index = False)
        
        splits = get_player_splits_clean(nom_joueur)
        splits.to_csv(f"{dossier}\splits.csv", index = False)
        
        logs = get_player_logs_clean(nom_joueur)
        logs.to_csv(f"{dossier}\logs.csv",index = False)
        
        # Récupérer l'image du joueur et la sauvegarder.
        image_url = get_player_headshot(nom_joueur)
        img_data = requests.get(image_url).content
        with open(f'{dossier}\{nom_joueur}.jpg', 'wb') as handler:
            handler.write(img_data)
        
        # Création des graphiques
        creation_graphique(stats, "Saison", "Moyenne des Points", dossier)
        creation_graphique(salary, "Saison", "Salaire", dossier)
        graph_W_L(logs,dossier)
    
def menu_joueur():
    dico_joueurs = {"1":"Stephen Curry",
                   "2":"Lebron James", 
                   "3":"Derrick Rose",
                   "4":"Kevin Durant",
                   "5":"Kawhi Leonard",
                   "6":"Nikola Jokic",
                   "7":"Luka Dončić",
                   "8":"Devin Booker",
                   "9":"Jayson Tatum",
                   "10":"Donnovan Mitchell"
                   }
    
    for numero,joueur in dico_joueurs.items():
        print(numero,": ",joueur)
    Choix = input('Donner votre choix de joueur entre 1 et 10: ')
    if Choix not in dico_joueurs.keys():
        Choix = input('redonner un choix valide : ')
    dossier_joueur = creation_dossier(os.path.dirname(__file__), 'Dossier joueur')
    scrapping_joueur(dico_joueurs[Choix], dossier_joueur)
    return

menu_joueur()
