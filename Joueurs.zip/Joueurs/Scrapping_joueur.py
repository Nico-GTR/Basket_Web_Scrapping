# -*- coding: utf-8 -*-
"""
Created on Sat Dec  7 14:26:54 2024

@author: Manoubi
"""
# Importer les modules pour faire le scrapping depuis BeautifulSoup :
import os
import requests
import pandas as pd
from bs4 import BeautifulSoup
from io import StringIO

# Importer les fonctions de l'API qu'on va utiliser plus tard :
from lookup import lookup
from players import get_player_suffix,get_game_logs,get_player_splits,get_player_headshot

# Importer les modules pour faire le scrapping depuis Selenium :
from selenium import webdriver
from selenium.webdriver.common.by import By

# Importer les modules pour faire les graphiques
import matplotlib.pyplot as plt


def scrapping_joueurs():
    """
    Cette fonction vérifie si un dossier pour les joueurs existe.
    Si ce n'est pas le cas, elle le crée et télécharge les données pour une
    liste de joueurs prédéfinis.
    Si le dossier existe déjà, elle indique que les données sont déjà
    disponibles.

    Parameters
    ----------
    None

    Returns
    -------
    None

    """
    # Vérifier si le dossier joueurs existe :
    if not verification_dossier(os.path.dirname(__file__), 'Dossier joueur'):
        # Si le dossier n'éxiste pas :
        print("Démarrage du téléchargement des données des joueurs...")
        liste_joueurs = ["Stephen Curry",
                       "Lebron James", 
                       "Derrick Rose",
                       "Kevin Durant",
                       "Kawhi Leonard",
                       "Nikola Jokic",
                       "Luka Dončić",
                       "Devin Booker",
                       "Jayson Tatum",
                       "Donnovan Mitchell"
                       ]
        # Créer et récupérer le chemin du dossier des joueurs
        dossier_joueur = creation_dossier(os.path.dirname(__file__), 'Dossier joueur')
        for i in range(len(liste_joueurs)):
            # Scrapper les informations sur le joueurs
            scrapping_joueur(liste_joueurs[i], dossier_joueur)
        print("Toutes les données des joueurs ont été téléchargées et sauvegardées !")
    else :
        print("Toutes les données des joueurs ont déjà été téléchargées et sauvegardées !")
    return

def verification_dossier(chemin_initial, nom_dossier):
    """
    Vérifie l'existence d'un dossier.

    Parameters
    ----------
    chemin_initial : str
        Chemin de base où chercher le dossier.
    nom_dossier : str
        Nom du dossier à vérifier.

    Returns
    -------
    bool
        True si le dossier existe, False sinon.

    """
    chemin_complet = os.path.join(chemin_initial, nom_dossier)
    return os.path.exists(chemin_complet)

def creation_dossier(chemin_initial, nom_dossier):
    """
    Crée un dossier s'il n'existe pas.

    Parameters
    ----------
    chemin_initial : str
        Chemin de base où créer le dossier.
    nom_dossier : str
        Nom du dossier à créer.

    Returns
    -------
    str
        Chemin complet du dossier créé.

    """
    dossier = os.path.join(chemin_initial, nom_dossier)
    if not os.path.exists(dossier):
        os.makedirs(dossier)
    return dossier

def get_stats(player_name):
    """
    Cette fonction trouve l'URL de la page du joueur, télécharge les données
    HTML, et extrait une table contenant les statistiques du joueur sous forme
    de DataFrame.

    Parameters
    ----------
    player_name : str
        Nom du joueur dont les statistiques doivent être récupérées.

    Returns
    -------
    pd.DataFrame or None
        DataFrame contenant les statistiques du joueur si la récupération est
        réussie, None sinon.

    """
    try:
        # Trouver l'url de la page du joueur
        name = lookup(player_name, ask_matches = True)
        suffix = get_player_suffix(name)
        url = "https://www.basketball-reference.com"+str(suffix)
        
        # Envoyer une requête à la page sports-reference
        response = requests.get(url)
        response.raise_for_status()  # Vérifiez si la demande a réussi.
    except requests.exceptions.RequestException as e:
        print(f"Error fetching the webpage: {e}")
        return None

    try:
        # Lire l'HTML avec BeautifulSoup
        soup = BeautifulSoup(response.content, "html.parser")

        # Trouver la table
        table = soup.find_all("table", {"id": "per_game_stats"})

        # Créer un Dataframe avec la table 
        df = pd.read_html(StringIO(str(table)))[0]
        
        # Garder que les colonnes qu'on a besoin
        columns_to_keep = ['Season', 'Age', 'Team', 'Lg', 'Pos', 'G', 'FT%', '3P', '2P', '2P%', '3P%', 'FT', 'TRB', 'AST', 'PTS', 'Awards']
        df = df[columns_to_keep]
        
        # Identifier la deuxième table des totaux et la supprimer (table gris)
        for idx, row in df.iterrows():
            if pd.isna(row['Season']) or not str(row['Season']).startswith(('1', '2')):  # Vérifiez les valeurs non valides ou non saisonnières
                break
        df = df.iloc[:idx]
        
        # Renommer les colonnes en français
        df.columns = [
            'Saison', 'Âge', 'Équipe', 'Ligue', 'Position', 'Matchs joués', 'Pourcentage de LF', '3 Points', '2 Points', 'Pourcentage de 2P',
            'Pourcentage de 3P', 'Lancers Francs', 'Rebonds', 'Passes Décisives', 'Moyenne des Points', 'Récompenses'
        ]

        
    except Exception as e:
        print(f"Error parsing the HTML or reading the table: {e}")
        return None
    return df
  
    
def get_game_highs(player_name):
    """
    Cette fonction récupère les meilleures performances du joueur pour la saison régulière,
    puis extrait et nettoie les informations pertinentes concernant les 
    meilleures statistiques de jeu comme les points, les rebonds et les passes.
    
    Parameters
    ----------
    player_name : str
        Le nom du joueur pour lequel on souhaite récupérer les meilleures performances.
    
    Returns
    -------
    pandas.DataFrame
        DataFrame contenant les statistiques pertinentes des meilleurs
        performances du joueur si la récupération est réussie, None sinon.
    """
    try:
        # Trouver l'url de la page du joueur
        name = lookup(player_name, ask_matches = True)
        suffix = get_player_suffix(name)
        url = "https://www.basketball-reference.com"+str(suffix)
        
        # Envoyer une requête à la page sports-reference
        response = requests.get(url)
        response.raise_for_status()  # Vérifiez si la demande a réussi.
    except requests.exceptions.RequestException as e:
        print(f"Error fetching the webpage: {e}")
        return None
    
    try:
        # Configurer les options pour le navigateur Chrome
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')  # Exécuter Chrome en mode sans interface graphique (headless)
        options.add_argument('--disable-gpu')  # Désactiver l'utilisation du GPU pour éviter certains problèmes
        options.add_argument('--no-sandbox')  # Désactiver le mode sandbox pour améliorer la compatibilité
        
        # Initialiser le navigateur Chrome avec les options configurées
        driver = webdriver.Chrome(options=options)
        
        # Charger la page web
        driver.get(url)
        
        # Localiser la table contenant les données souhaitées
        table = driver.find_element(By.ID, 'highs-reg-season')
        html_content = table.get_attribute('outerHTML') # Extraire le contenu HTML de la table
        
        # Analyser le contenu de la table avec Pandas
        df = pd.read_html(html_content)[0]
        
        # Supprimer les lignes où tous les éléments sont des valeurs manquantes (NaN)
        df = df.dropna(how='all')

        # Renommer les colonnes en français
        df.columns = ['Saison', 'Âge', 'Équipe', 'Ligue', 'Minutes jouées',
                      'Tirs réussis', 'Tirs tentés','3 Points réussis',
                      '3 Points tentés', '2 Points réussis', '2 Points tentés',
                      'Lancers francs réussis', 'Lancers francs tentés',
                      'Rebonds offensifs', 'Rebonds défensifs',
                      'Rebonds totaux', 'Passes décisives', 'Interceptions', 
                      'Contres', 'Ballons perdus', 'Fautes', 'Points',
                      'Évaluation (GmSc)']
        
        # Supression du tableau gris (tableau des totals)
        df = df[~df['Saison'].str.contains("Career", na=False)]
        df = df[~df['Saison'].str.contains("Seasons", na=False)]
        df = df[~df['Saison'].str.contains("Season", na=False)]
        
        # Garder que les colonnes qu'on a besoin
        colonnes = ['Saison', 'Âge', 'Équipe', 'Ligue', 'Minutes jouées',
                      'Tirs réussis','3 Points réussis',
                      '2 Points réussis',
                      'Lancers francs réussis',
                      'Rebonds offensifs', 'Rebonds défensifs',
                      'Rebonds totaux', 'Passes décisives', 'Interceptions', 
                      'Contres', 'Points']
        df = df[colonnes]

        return df
    except Exception as e:
        print(f"Error: {e}")
        return None
    
def get_salary(player_name):
    """
    Cette fonction récupère les salaires du joueur à partir de sa page sur basketball-reference. Elle extrait les données 
    relatives au salaire de chaque saison.
    
    Parameters
    ----------
    player_name : str
        Le nom du joueur pour lequel on souhaite récupérer les informations sur le salaire.
    
    Returns
    -------
    pandas.DataFrame
        DataFrame contenant les informations sur le salaire du joueur si la
        récupération est réussie, None sinon.
    """
    try:
        # Trouver l'url de la page du joueur :
        name = lookup(player_name, ask_matches = True)
        suffix = get_player_suffix(name)
        url = "https://www.basketball-reference.com"+str(suffix)
        
        # Envoyer une requête à la page sports-reference :
        response = requests.get(url)
        response.raise_for_status()  # Vérifiez si la demande a réussi.
    except requests.exceptions.RequestException as e:
        print(f"Error fetching the webpage: {e}")
        return None
    
    try:
        # Configurer les options pour le navigateur Chrome :
        options = webdriver.ChromeOptions()
        options.add_argument('--headless')  # Exécuter Chrome en mode sans interface graphique (headless).
        options.add_argument('--disable-gpu')  # Désactiver l'utilisation du GPU pour éviter certains problèmes.
        options.add_argument('--no-sandbox')  # Désactiver le mode sandbox pour améliorer la compatibilité.
        
        # Initialiser le navigateur Chrome avec les options configurées :
        driver = webdriver.Chrome(options=options)
        
        # Charger la page web :
        driver.get(url)
        
        # Localiser la table contenant les données souhaitées :
        table = driver.find_element(By.ID, 'all_salaries')
        html_content = table.get_attribute('outerHTML') # Extraire le contenu HTML de la table.
        
        # Analyser le contenu de la table avec Pandas :
        df = pd.read_html(html_content)[0]
        
        # Supprimer les lignes où tous les éléments sont des valeurs manquantes (NaN) :
        df = df.dropna(how='all')
        
        # Supprimer le tableau des totals (tableau gris) :
        df = df[~df['Season'].str.contains("Career", na=False)]
        
        # Renommer les colonnes :
        df.columns = ['Saison', "Équipes", "Ligue", "Salaire"]
        
        return df
        
    except Exception as e:
        print(f"Error: {e}")
        return None
    
def get_player_logs_clean(nom_joueur):
    """
    Cette fonction récupère les journaux de matchs du joueur pour la saison en cours depuis l'API et les nettoie. Elle garde uniquement 
    les colonnes pertinentes et les renommes.
    
    Parameters
    ----------
    nom_joueur : str
        Le nom du joueur pour lequel on souhaite récupérer les journaux de matchs.
    
    Returns
    -------
    pandas.DataFrame
        Un DataFrame contenant les journaux de matchs du joueur, après avoir nettoyé les données et renommé 
        les colonnes.
    """
    # Créer le dataframe des journaux en utilisant une fonction de l'API :
    df = get_game_logs(nom_joueur, 2024,playoffs=False, ask_matches=True)
    
    # Garder que les colonnes pértinentes :
    colonnes = ["DATE","OPPONENT","RESULT","GS","MP","FG","3P","3P%","FT","FT%","AST","PTS"]    
    df = df[colonnes]
    
    # Renommer les colonnes en français :
    df.columns = ["Date", "Adversaire", "Résultat", "Titulaire", "Minutes jouées", 
            "Tirs réussis", "3 points", "3 points %", "Lancers francs", 
            "Lancers francs %", "Passes décisives", "Points"]
    return df

def get_player_splits_clean(nom_joueur):
    """
    Cette fonction récupère les statistiques de division du joueur depuis l'API,
    en filtrant et en nettoyant les données. Elle garde uniquement les catégorie
    pertinentes et renomme les colonnes.
    
    Parameters
    ----------
    nom_joueur : str
        Le nom du joueur pour lequel on souhaite récupérer les statistiques de division.
    
    Returns
    -------
    pandas.DataFrame
        Un DataFrame contenant les statistiques de division filtrées.
    """
    # Créer le dataframe des catégories en utilisant une fonction de l'API :
    df = get_player_splits(nom_joueur, '')
    
    # Renommer les colonnes en français :
    df.columns = ["Catégories", "Valeur", "Minutes jouées", "Points", "Rebonds totaux", "Passes décisives"]
    
    # Garder que les lignes qu'on a besoin :
    df = df[df['Catégories'].isin(['Opponent', 'Minutes'])]
    
    return df

def creation_graphique(df, x, y, dossier):
    """
    Cette fonction crée un graphique à barres à partir d'un DataFrame donné.
    Elle utilise les colonnes spécifiées pour les 
    axes x et y, puis sauvegarde le graphique dans un dossier donné.
    
    Parameters
    ----------
    df : pandas.DataFrame
        Le DataFrame contenant les données à visualiser.
    x : str
        Le nom de la colonne à utiliser pour l'axe des x.
    y : str
        Le nom de la colonne à utiliser pour l'axe des y.
    dossier : str
        Le chemin du dossier où sauvegarder le graphique généré.
    
    Returns
    -------
    None
        Cette fonction ne retourne rien, mais elle sauvegarde un graphique dans
        le dossier spécifié.
    """
    fig = plt.figure(figsize=(20, 5)) # Configurer les dimensions du graphique
    plt.bar(df[x], df[y], color='maroon', width=0.4)
    plt.xlabel(x)
    plt.ylabel(y)
    plt.title(f"{y} par {x}")
    
    # Sauvegarder le graphique
    plt.savefig(f"{dossier}/Graphique_representant_les_{y}.png", dpi=300, bbox_inches='tight')
    plt.close()
    return

def graph_W_L(original_df, dossier):
    """
    Cette fonction génère un graphique montrant les résultats des matchs sous
    forme de barres. Les victoires sont colorées en vert et les défaites en
    rouge, et les points obtenus pour chaque match sont affichés. Le graphique
    est ensuite sauvegardé dans un dossier spécifié.
    
    Parameters
    ----------
    original_df : pandas.DataFrame
        Le DataFrame contenant les résultats des matchs, y compris la colonne
        'Résultat' pour chaque match.
    dossier : str
        Le chemin du dossier où sauvegarder le graphique généré.
    
    Returns
    -------
    None
        Cette fonction ne retourne rien, mais elle sauvegarde un graphique des
        résultats dans le dossier spécifié.
    """
    # Créer un nouveau DataFrame avec seulement la colonne 'Résultat'
    df = original_df[['Résultat']].copy()
    
    # Extraire les résultats sous forme de nombre (+11, -8, etc.)
    df['Points'] = df['Résultat'].str.extract('([+-]?\d+)').astype(int)
    
    # Créer une nouvelle colonne pour le numéro du match
    df['Nombre du match'] = range(1, len(df) + 1)
    
    # Créer le graphique à barres
    plt.figure(figsize=(10, 6))
    
    # Définir les couleurs selon le signe des points (vert pour les victoires, rouge pour les défaites)
    colors = df['Points'].apply(lambda x: 'green' if x > 0 else 'red')  # Vert pour les points positifs, rouge pour les négatifs
    plt.bar(df['Nombre du match'], df['Points'], color=colors)
    
    # Ajouter des labels et un titre
    plt.xlabel('Nombre du match')
    plt.ylabel('Points')
    plt.title('Résultats des matchs (Points)')
    
    # Ajouter une ligne horizontale à 0
    plt.axhline(0, color='black', linewidth=0.8)  # Ligne horizontale à 0
    
    # Définir les limites de l'axe y pour plus de clarté
    plt.ylim(min(df['Points']) - 5, max(df['Points']) + 5)
    
    # Sauvegarde du graphique
    plt.savefig(f"{dossier}/Résultat_parties.png", dpi=300, bbox_inches='tight')
    plt.close()

    return


def scrapping_joueur(nom_joueur,dossier_joueur):
    """
    Cette fonction effectue le scraping des données d'un joueur. Si le dossier
    du joueur n'existe pas, elle crée le dossier, télécharge les informations 
    du joueur et les enregistre sous forme de fichiers CSV.
    Elle récupère également l'image du joueur et génère des graphiques pour 
    les statistiques.
    
    Parameters
    ----------
    nom_joueur : str
        Le nom du joueur pour lequel les données doivent être récupérées.
    dossier_joueur : str
        Le chemin du dossier où enregistrer les données du joueur.
    
    Returns
    -------
    None
        Cette fonction ne retourne rien, mais elle sauvegarde les fichiers CSV
        et les graphiques dans le dossier spécifié.
    """
    # Vérifier si le dossier éxiste 
    dossier_verifié = verification_dossier(dossier_joueur, nom_joueur)
    
    if dossier_verifié == False:
        print(f"\nCollecte des informations pour {nom_joueur} en cours...\n")
        # Création du dossier du joueur
        dossier = creation_dossier(dossier_joueur, nom_joueur)
        
        # Créer les DataFrames et les sauvegarder dans le dossier approprié
        stats = get_stats(nom_joueur)
        stats.to_csv(f"{dossier}\stats.csv",index =False)
        print(f"\nFichier 'stats.csv' sauvegardé pour {nom_joueur}.\n")
        
        game_highs = get_game_highs(nom_joueur)
        game_highs.to_csv(f"{dossier}\game_highs.csv", index = False)
        print(f"\nFichier 'game_highs.csv' sauvegardé pour {nom_joueur}.\n")
        
        salary = get_salary(nom_joueur)
        salary.to_csv(f"{dossier}\salary.csv", index = False)
        print(f"\nFichier 'salary.csv' sauvegardé pour {nom_joueur}.\n")
        
        splits = get_player_splits_clean(nom_joueur)
        splits.to_csv(f"{dossier}\splits.csv", index = False)
        print(f"\nFichier 'splits.csv' sauvegardé pour {nom_joueur}.\n")
        
        logs = get_player_logs_clean(nom_joueur)
        logs.to_csv(f"{dossier}\logs.csv",index = False)
        print(f"\nFichier 'logs.csv' sauvegardé pour {nom_joueur}.\n")
        
        # Récupérer l'image du joueur et la sauvegarder.
        image_url = get_player_headshot(nom_joueur)
        img_data = requests.get(image_url).content
        with open(f'{dossier}\{nom_joueur}.jpg', 'wb') as handler:
            handler.write(img_data)
        print(f"Image de {nom_joueur} sauvegardée avec succès.")
        
        # Création et sauvegarde des graphiques
        creation_graphique(stats, "Saison", "Moyenne des Points", dossier)
        creation_graphique(salary, "Saison", "Salaire", dossier)
        graph_W_L(logs,dossier)
        print(f"\nGraphiques créés pour {nom_joueur}.\n")
        
        print(f"\nLes informations de {nom_joueur} ont été sauvegardées avec succès !\n")
    else:
        print(f"\nLe dossier pour {nom_joueur} existe déjà. Aucune action n'est nécessaire.\n")

    
if __name__ == "__main__":
    scrapping_joueurs()